drop table if exists nodes;
create table nodes(
  node_id integer primary key autoincrement,
  node_text text not null,
  is_root boolean not null
);

drop table if exists node_tags;
create table node_tags(
  tag_id integer primary key autoincrement,
  node_id integer not null,
  author text not null,
  score integer check (score in (0, 1, 2, 3, 4)),
  foreign key(node_id) references nodes(node_id)
);
