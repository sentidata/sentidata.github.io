import sys
reload(sys)
sys.setdefaultencoding('utf8')

import os
import sqlite3
from nltk.tokenize.moses import MosesDetokenizer

detokenizer = MosesDetokenizer()
conn = sqlite3.connect('label.db')


def parse_list(s, start=0):
    x = []
    i = start
    while i < len(s):
        c = s[i]
        if c == '(':
            y, i = parse_list(s, i + 1)
            x = x + y
        if c == ')':
            return x + [s[start: i]], i
        i += 1
    return x + [s]


f_train = open('train.txt', 'w')
inserts = []
for file_to_tag in os.listdir("dataset"):
    if file_to_tag.endswith('.txt'):
        print 'processing: ', file_to_tag
        file_path = os.path.join("dataset/", file_to_tag)
        # file_path = 'results/13638735.txt'
        post_file = open(file_path)
        for line in post_file.readlines():
            sentence = line.strip()
            node_lists = []
            token_lists = parse_list(sentence)
            for ind in range(0, len(token_lists)):
                if '(' not in token_lists[ind]:
                    text = token_lists[ind].split(' ')[1].strip()
                    node_lists.append(text)
                else:
                    node_tokens = []
                    for part in token_lists[ind].split(' '):
                        if ')' in part:
                            node_tokens.append(part.split(')')[0])
                    node_lists.append(detokenizer.detokenize(node_tokens, return_str=True))
            node_lists = [node_lists[-1]] + node_lists[:-2]
            for ind in range(0, len(node_lists)):
                if ind == 0:
                    inserts.append((node_lists[ind].decode('utf-8'), 'true'))
                else:
                    inserts.append((node_lists[ind].decode('utf-8'), 'false'))
                f_train.write(node_lists[ind].decode('utf-8') + '\n')

inserts = list(set(inserts))
c = conn.cursor()
c.executemany("insert into nodes(node_text, is_root) values (?,?)", inserts)
conn.commit()
conn.close()
