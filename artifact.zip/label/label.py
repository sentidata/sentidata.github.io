import os

from flask import Flask

from db import init_db
from views import view

app = Flask(__name__)
app.config.from_object(__name__)

# Load default config and override config from an environment variable
app.config.update(dict(
    DATABASE=os.path.join(app.root_path, 'label.db'),
    SECRET_KEY='opinion'
))


app.config.from_envvar('FLASKR_SETTINGS', silent=True)

app.register_blueprint(view)


@app.cli.command('initdb')
def initdb_command():
    """Initializes the database."""
    init_db()
    print('Initialized the database.')


if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000)
