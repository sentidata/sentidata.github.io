import sys
reload(sys)
sys.setdefaultencoding('utf8')

import os
import sqlite3
from nltk.tokenize.moses import MosesDetokenizer

detokenizer = MosesDetokenizer()
conn = sqlite3.connect('label.db')
query = """
        select nodes.node_id, nodes.node_text, avg(score)
        from nodes, node_tags where nodes.node_id = node_tags.node_id group by nodes.node_id
        """
c = conn.cursor()
c.execute(query)
score_dict = {}
for (node_id, text, score) in c:
    score_dict[text] = {'score': score, 'id': node_id}
print len(score_dict)


def parse_list(s, start=0):
    x = []
    i = start
    while i < len(s):
        c = s[i]
        if c == '(':
            y, i = parse_list(s, i + 1)
            x = x + y
        if c == ')':
            return x + [s[start: i]], i
        i += 1
    return x + [s]


f_train = open('for_training.txt', 'w')
inserts = []
for file_to_tag in os.listdir("dataset"):
    if file_to_tag.endswith('.txt'):
        print 'processing: ', file_to_tag
        file_path = os.path.join("dataset/", file_to_tag)
        post_file = open(file_path)
        for line in post_file.readlines():
            sentence = line.strip()
            node_lists = []
            score_lists = []
            token_lists = parse_list(sentence)
            for ind in range(0, len(token_lists)):
                score = int(token_lists[ind].split(' ')[0][-1])
                if '(' not in token_lists[ind]:
                    text = token_lists[ind].split(' ')[1].strip()
                    node_lists.append(text)
                    score_lists.append(score)
                else:
                    node_tokens = []
                    for part in token_lists[ind].split(' '):
                        if ')' in part:
                            node_tokens.append(part.split(')')[0])
                    node_lists.append(detokenizer.detokenize(node_tokens, return_str=True))
                    score_lists.append(score)
            node_lists = [node_lists[-1]] + node_lists[:-2]
            score_lists = [score_lists[-1]] + score_lists[:-2]
            for ind in range(0, len(node_lists)):
                if node_lists[ind] in score_dict:
                    node_score = int(round(score_dict[node_lists[ind]]))
                else:
                    node_score = score_lists[ind]
                f_train.write(str(node_score) + ' ' + node_lists[ind].decode('utf-8') + '\n')
            f_train.write('\n')

f_train.close()