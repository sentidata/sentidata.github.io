from flask import json
from flask import redirect, render_template, request, url_for, Flask, Blueprint, flash
from flask import session

from db import get_db

view = Blueprint('views', __name__)


@view.route('/')
def index():
    db = get_db()
    cur = db.execute('select author, count(tag_id) as cnt from node_tags '
                     'where author != "sec_default" '
                     'group by author order by cnt desc limit 5;')
    winners = cur.fetchall()
    return render_template('index.html', winners=winners)


@view.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        if request.form['username']:
            session['user'] = request.form['username']
            flash('You were logged in')
            return redirect(url_for('views.show_sentence'))
    return redirect(url_for('views.index'))


@view.route('/sentence', methods=['GET', 'POST'])
def show_sentence():
    if 'user' in session:
        db = get_db()
        query = """
            select nodes.node_id, nodes.node_text from nodes
            where nodes.node_id not in
              (select node_id from (select node_id, count(*) as cnt from node_tags
              group by node_id having cnt>1)
              union select node_tags.node_id from node_tags where author='%s')
            order by random() limit 20;
        """ % (session['user'])
        cur = db.execute(query)
        nodes = cur.fetchall()
        phrases = []
        nodes_dict = {}
        node_ids = ''
        for (id, name) in nodes:
            # print id, name, cnt
            nodes_dict[str(id)] = {'name': name, 'score': None}
            node_ids = node_ids + str(id) + ','
        if node_ids != '':
            query = """
                        SELECT node_id, avg(score)
                        FROM node_tags
                        WHERE node_id in (%s) AND author in (%s)
                        GROUP BY score;
                    """ % (node_ids[:-1], '"' + session['user'] + '", "sec_default"')
            cur = db.execute(query)
            scores = cur.fetchall()
            for (id, score) in scores:
                nodes_dict[str(id)]['score'] = int(round(score))
            # print nodes_dict
            for key, value in nodes_dict.iteritems():
                phrases.append({'id': key, 'text': value['name'].replace('-LRB-', '(').replace('-RRB-', ')')
                               .replace('-LSB-', '[').replace('-RSB-', ']').replace('-LCB-', '{').replace('-RCB-', '}'),
                                'score': value['score']})
        # render_nodes = {'sentence': node_sentence, 'phrases': phrases}
        render_nodes = {'sentence': None, 'phrases': phrases}
        return render_template('label.html', nodes=render_nodes)
    else:
        return redirect(url_for('views.index'))


@view.route('/label', methods=['POST'])
def label_sentence():
    data = request.form.to_dict()
    labels = []
    db = get_db()
    for opinion in request.form.getlist('opinion'):
        query = """insert into opinions(node_id, opinion_type, author)
                values('%s', '%s', '%s')""" % (data['sentence'], opinion, session['user'])
        db.execute(query)
        db.commit()
    for key, value in data.iteritems():
        # if key == 'opinion':
        #     query = """insert into opinions(node_id, opinion_type, author)
        #             values('%s', '%s', '%s')""" % (data['sentence'], value, session['user'])
        #     db.execute(query)
        #     db.commit()
        if 'group' in key:
            labels.append((int(key.replace('group', '').strip()), session['user'], int(value)))
    db.executemany("insert into node_tags(node_id, author, score) values (?,?,?)", labels)
    db.commit()
    return redirect(url_for('views.show_sentence'))
