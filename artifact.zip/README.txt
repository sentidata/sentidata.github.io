The package of artifacts consists of two parts: datasets and web app used to label the data. The artifacts are associated with the paper we published at ICSE 2018, which is also included in the package:

Bin Lin, Fiorella Zampetti, Gabriele Bavota, Massimiliano Di Penta, Michele Lanza, and Rocco Oliveto. 2018. Sentiment Analysis for Software Engineering: How Far Can We Go?. In ICSE '18: ICSE '18: 40th International Conference on Software Engineering , May 27-June 3, 2018, Gothenburg, Sweden.

1. datasets
The datasets are located in the "dataset" folder. The CSV files contains the sentence (in column "sentence") and the sentiment expressed (in column "oracle"). "AppReviews.csv" are "StackOverflow.csv" contain sentences labeled with sentiment scores: 1 for positive, 0 for neutral, and -1 for negative.

File "StackOverflow_for_CoreNLP.txt" contained all the sentences/nodes we labeled for training CoreNLP model, and the sentences are formatted as binary trees, which is required by the CoreNLP SentimentTraining component. Five-scale sentiment scores are used for these nodes: 4 for positive, 3 for slightly positive, 2 for neutral, 1 for slightly negative, and 0 for negative. Stanford CoreNLP tool can be downloaded from https://stanfordnlp.github.io/CoreNLP/, then simply run "java -mx8g edu.stanford.nlp.sentiment.SentimentTraining -numHid 25 -trainPath StackOverflow_for_CoreNLP.txt -train -model model.ser.gz" to get the trained model.

2. web app
The labeling app allows users to label to random nodes in the database. It also provides a chart for users to view who labels the most nodes. For easy reviewing, we have dockerized our web app, users can simply pull the docker image from docker hub and run it. To do so, make sure you have docker installed: https://docs.docker.com/install/#supported-platforms

Simply execute the following two commands to test the web app:
docker pull wzblin/sentidata-label:latest
docker run -d -p 5000:5000 sentidata-label:latest

Open the browser and enter "http://127.0.0.1:5000" to start exploring the labeling app.

The source code of the app can be found in the "label" folder, if you are interested in the customization of the labeling app, please read the extra instructions below.
---------------------
Extra instructions for customizing the app:
1. Dockerfile is included in the folder, which allows you to easily dockerize the web app yourself.
2. The app is developed with Python 2.7 and sqlite3. To modify and run this labeling app, you need to have flask and NLTK python pakcages installed.
3. If you want to empty the database, In the project folder, execute the following two commands:
export FLASK_APP=label.py
flask initdb
4. If you want to add nodes to be labeled into the database, execute "python dump_data.py". The script supports to convert Penn Tree Bank (PTB) format texts into database compatible nodes. Text data should be stored in "txt" files in the "dataset" folder. A sentence in PTB format looks like this:

(1 (1 (2 (2 Is) (2 there)) (1 (2 (2 any) (2 Library)) (1 (2 in) (1 (2 Java) (1 (2 that) (1 (2 has) (1 (2 (2 Cluster) (2 (2 Heat) (2 Maps))) (2 (2 already) (2 implemented))))))))) (2 ?))

Users can use Stanford CoreNLP tool to generate PTB strings for sentences. or more information about Penn Tree Bank, please refer to the website of Stanford CoreNLP: https://nlp.stanford.edu/sentiment/code.html
5. After labeling, users can run python training.py to generate the training file compatible with sentiment model trainer of Stanford CoreNLP. Then execute the following two commands:

java -cp "*" -mx5g edu.stanford.nlp.sentiment.BuildBinarizedDataset -input for_training.txt > PBT_training.txt
java -mx8g edu.stanford.nlp.sentiment.SentimentTraining -numHid 25 -trainPath PBT_training.txt -train -model model.ser.gz


For more information and doubts, please contact Bin Lin via bin.lin@usi.ch.
